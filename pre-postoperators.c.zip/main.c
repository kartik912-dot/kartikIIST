#include<stdio.h>

void main()
{
     //1.   int a=10;
     //   printf("%d\n",a);
    //   ++a;
    // printf("%d\n",a);
   //  a++;
   //  printf("%d\n",a);
   
   
 // 2.   int a=10,b;
 //  b=a++;
  // printf("%d\n%d",a,b);
  
  int a=10,b;
  b=++a;
  printf("%d\n%d",a,b);
  
    
}